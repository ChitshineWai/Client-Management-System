<?php
session_start();
include("../connection.php");
if($_SESSION['pass'] == ""){
  header("location:../index.php");
}else{
$delete_id = $_GET['id'];
$selc = "DELETE FROM `service_tb` WHERE id ='$delete_id'";
$con->query($selc);
header("location:manage_service.php");
}
?>