-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 01, 2022 at 12:36 PM
-- Server version: 5.7.36
-- PHP Version: 8.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clientms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `pass` varchar(225) NOT NULL,
  `phone` varchar(225) NOT NULL,
  `registerdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `pass`, `phone`, `registerdate`) VALUES
(1, 'MgMg', 'admin@gmail.com', '123', '09451387', '2022-07-29 15:34:11');

-- --------------------------------------------------------

--
-- Table structure for table `client_tb`
--

DROP TABLE IF EXISTS `client_tb`;
CREATE TABLE IF NOT EXISTS `client_tb` (
  `id` int(225) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(225) NOT NULL,
  `account_type` varchar(225) NOT NULL,
  `contact_name` varchar(225) NOT NULL,
  `company_name` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `city` varchar(225) NOT NULL,
  `state` varchar(225) NOT NULL,
  `zip_code` varchar(225) NOT NULL,
  `work_ph_number` varchar(225) NOT NULL,
  `cell_ph_number` varchar(225) NOT NULL,
  `other_ph_number` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `website_add` varchar(225) NOT NULL,
  `Notes` varchar(225) NOT NULL,
  `creation_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client_tb`
--

INSERT INTO `client_tb` (`id`, `account_id`, `account_type`, `contact_name`, `company_name`, `address`, `city`, `state`, `zip_code`, `work_ph_number`, `cell_ph_number`, `other_ph_number`, `email`, `password`, `website_add`, `Notes`, `creation_date`) VALUES
(1, '52739', 'Active Account', 'Mr.AungKoKo', 'BussTradeMyanmar', 'Hledan ', 'Yangon', 'KamarYauk', '15454545', '09172284', '0745455', '05454521', 'koaung@gmail.com', 'dabf0e174899c052c048c4f8b9b36e63', 'www.btm.com', 'Clean and Slow ', '2022-07-30 16:26:52'),
(2, '30654', 'Inactive Account', 'asdf', 'asdf', 'asdf', 'asdf', 'adsf', 'asdf', '456546', '4564', '5645', 'koaung@gmail.com', '1cf04619d373e41edbd850ba66237d96', 'asdf', 'asdf', '2022-07-30 15:24:14');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_tb`
--

DROP TABLE IF EXISTS `invoice_tb`;
CREATE TABLE IF NOT EXISTS `invoice_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(225) NOT NULL,
  `service_id` varchar(225) NOT NULL,
  `Billing_id` varchar(225) NOT NULL,
  `posting_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_tb`
--

INSERT INTO `invoice_tb` (`id`, `user_id`, `service_id`, `Billing_id`, `posting_date`) VALUES
(1, '2', '4', '4562', '2022-07-31 10:22:28'),
(2, '2', '4', '1185', '2022-07-31 10:22:41'),
(3, '2', '5', '1185', '2022-07-31 10:22:41'),
(8, '1', '4', '2776', '2022-07-31 15:52:51'),
(7, '1', '4', '1910', '2022-07-31 11:31:28');

-- --------------------------------------------------------

--
-- Table structure for table `service_tb`
--

DROP TABLE IF EXISTS `service_tb`;
CREATE TABLE IF NOT EXISTS `service_tb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(225) NOT NULL,
  `service_price` varchar(225) NOT NULL,
  `creation_date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_tb`
--

INSERT INTO `service_tb` (`id`, `service_name`, `service_price`, `creation_date`) VALUES
(4, 'Website Developments', '150000', '2022-07-30 11:10:54'),
(5, 'Network Service', '450000', '2022-07-30 11:10:54');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
